<?php

$_lang['localizator_prop_snippet'] = 'Snippet, which will be called to output the results of work. Default - "pdoResources"';
$_lang['localizator_prop_class'] = 'Object. Default - "modResource"';
$_lang['localizator_prop_localizator_key'] = 'Key localization. The default is the current';