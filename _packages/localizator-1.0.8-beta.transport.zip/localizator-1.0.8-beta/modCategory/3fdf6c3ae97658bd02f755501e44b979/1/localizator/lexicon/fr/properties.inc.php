<?php

$_lang['localizator_prop_snippet'] = 'Extrait de code, qui s’appellera pour générer les résultats des travaux. Par défaut - «pdoResources»';
$_lang['localizator_prop_class'] = 'Objet. Par défaut - «modResource»';
$_lang['localizator_prop_localizator_key'] = 'Localisation de clés. La valeur par défaut correspond au courant';