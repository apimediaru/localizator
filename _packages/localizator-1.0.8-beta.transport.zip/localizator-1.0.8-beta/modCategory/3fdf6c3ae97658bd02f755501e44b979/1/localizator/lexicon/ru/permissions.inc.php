<?php

$_lang['localizatorcontent_list'] = 'Разрешает вывод списка локализаций ресурса';
$_lang['localizatorcontent_view'] = 'Разрешает просмотр локализации ресурса';
$_lang['localizatorcontent_save'] = 'Разрешает изменение локализации ресурса';
