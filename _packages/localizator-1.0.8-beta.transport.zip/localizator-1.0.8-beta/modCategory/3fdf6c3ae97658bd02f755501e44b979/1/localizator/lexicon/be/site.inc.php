<?php

$_lang['test'] = 'Тэст';