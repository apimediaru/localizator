<?php
require_once (dirname(__DIR__) . '/loctemplatevarresource.class.php');
class locTemplateVarResource_mysql extends locTemplateVarResource {}