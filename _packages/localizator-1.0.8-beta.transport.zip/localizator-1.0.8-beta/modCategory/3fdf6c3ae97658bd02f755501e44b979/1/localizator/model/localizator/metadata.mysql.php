<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'localizatorLanguage',
    1 => 'localizatorContent',
    2 => 'locTemplateVarResource',
  ),
);